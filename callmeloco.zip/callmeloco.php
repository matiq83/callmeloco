<?php
/*
Plugin Name: CallMeLoco Customization
Description: Plugin will make CallMeLoco Customization
Version: 1.0.0
Author: Muhammad Atiq
*/

// Make sure we don't expose any info if called directly
if ( !function_exists( 'add_action' ) ) {
    echo "Hi there!  I'm just a plugin, not much I can do when called directly.";
    exit;
}

define( 'CML_PLUGIN_NAME', 'Call Me Loco Customization' );
define( 'CML_SITE_NAME', 'Call Me Loco' );
define( 'CML_PLUGIN_PATH', plugin_dir_path(__FILE__) );
define( 'CML_PLUGIN_URL', plugin_dir_url(__FILE__) );
define( 'CML_SITE_BASE_URL',  rtrim(get_bloginfo('url'),"/")."/");
define( 'CML_LANG_DIR', dirname( plugin_basename(__FILE__) ).'/language/' );
define( 'CML_GOOGLE_CLIENT_ID', '1068609518197-ufed3k2a0crd2fj5343ampq3ntjvhdm6.apps.googleusercontent.com' );
define( 'CML_GOOGLE_CLIENT_SECRET', 'pNK-xJMpRGAeZJRlTw3WQ5I8' );
define( 'CML_TWILIO_ACC_SID', 'AC505a1dbe8d9ce9141554d31c8da63461' );
define( 'CML_TWILIO_AUTH_TOKEN', 'eab01740b585067eeb6aeb913afc0cbc' );
define( 'CML_TWILIO_FROM', '+12315592021' );
define( 'CML_INVITE_FRIEND_URL', 'https://callmeloco.com/invite-friends/' );
define( 'CML_REGISTRATION_URL', 'https://callmeloco.com/callmeloco_register123/' );

require_once CML_PLUGIN_PATH.'includes/cml_class.php';

register_activation_hook( __FILE__, array( 'CML', 'cml_install' ) );
register_deactivation_hook( __FILE__, array( 'CML', 'cml_uninstall' ) );