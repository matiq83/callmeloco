<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */

/**
 * Class that will hold functionality for admin side
 *
 * PHP version 5
 *
 * @category   Admin Side Code
 * @package    CallMeLoco Customization
 * @author     Muhammad Atiq
 * @version    1.0.0
 * @since      File available since Release 1.0.0
*/

class CML_Admin extends CML 
{
    //Admin side starting point. Will call appropriate admin side hooks
    public function __construct() {
        
        do_action('cml_before_admin', $this );
        //All admin side code will go here
        
        add_action( 'admin_menu', array( $this, 'cml_admin_menus' ),100 ); 
        add_action( 'wp_ajax_cml_save_username', array( $this, 'cml_save_username') );
        add_action( 'wp_ajax_arf_retrieve_form_entry', array( $this, 'cml_retrieve_form_entry'), 2 );
        add_action( 'wp_ajax_cml_list_referrals', array( $this, 'cml_list_referrals') );
        add_filter( 'gettext', array( $this, 'cml_update_text'),100, 3 );
        add_action( 'current_screen', array( $this, 'cml_restrict_admin_pages' ) );
        
        do_action('cml_after_admin', $this );            
    }

    public function cml_admin_menus(){
        
        add_menu_page( CML_PLUGIN_NAME, CML_PLUGIN_NAME, 'manage_options', 'cml_settings', array( $this, 'cml_settings' ) );
        add_submenu_page( 'cml_settings', CML_PLUGIN_NAME.' Settings', 'Settings', 'manage_options', 'cml_settings', array( $this, 'cml_settings' ) );
        add_submenu_page( 'cml_settings', 'Referrals', 'Referrals', 'manage_options', 'cml_referrals', array( $this, 'cml_referrals' ) );
        $this->cml_update_menu_labels();
    }    
    
    public function cml_list_referrals() {
        
        $sorting    = $_REQUEST['jtSorting'];
        $start      = $_REQUEST['jtStartIndex'];
        $end        = $start+$_REQUEST['jtPageSize'];
        
        $records = $this->cml_get_data( "cml_invitations" );
        $recordCount = sizeof($records);
        if( $sorting != "" ) {
            $sorting_arr = explode(" ",$sorting);
            $orderby = trim($sorting_arr[0]);
            $order = trim($sorting_arr[1]);
        }
        $users = $this->cml_get_data("users");
        $sweepstakes = $referrals = array();
        foreach( $users as $user ) {
            $referrals[$user->ID] = array( 'name'=>$user->display_name, 'email' => $user->user_email );
            $sweepstakes[$user->ID] = get_user_meta( $user->ID, 'cml_sweepstakes', true );
        }
        $rows = $final_rows = array();
        $index = 0;
        foreach ( $records as $row ) {
            $record = array();
            $record['Action'] = '<input type="checkbox" value="'.$row->id.'" class="cml_select_item" /> <a class="cml_edit_icon" title="Edit" href="admin.php?page=cml_referrals&action=edit&id='.$row->id.'"></a> <a class="cml_del_icon" title="Delete" href="admin.php?page=cml_referrals&action=del&id='.$row->id.'" onclick="javascript: return confirm(\'Are you sure you want to delete that item?\');"></a>';
            $record['ID'] = $row->id;
            $record['ReferBy'] = ($referrals[$row->inviter]['name']!="")?$referrals[$row->inviter]['name'].' ('.$referrals[$row->inviter]['email'].')':"";
            $record['ReferTo'] = $row->invited;//($referrals[$row->invited_id]['name']!="")?$referrals[$row->invited_id]['name'].' ('.$referrals[$row->invited_id]['email'].')':""; 
            $record['Status'] = $row->status; 
            $record['Amount'] = ($row->amount_paid!="")?"$".$row->amount_paid:"";
            $record['DateCreated'] = date('Y-m-d H:i:s',$row->date_time_created);
            $record['DateUpdated'] = date('Y-m-d H:i:s',$row->date_time);
            $record['ReferByCountry'] = $row->inviter_country;
            $record['Sweepstakes'] = ($sweepstakes[$row->inviter]!="")?$sweepstakes[$row->inviter]:'Sweepscoach';
            $record['ReferToCountry'] = $row->invited_country;
            $rows[] = $record;
        }
        
        $rows = $this->array_sort($rows, $orderby,$order);
        foreach ( $rows as $row ) {
            if($index >= $start && $index <= $end) {
                $final_rows[] = $row;
            }
            $index++;
        }
     
        $jTableResult = array();
        $jTableResult['Result'] = "OK";
        $jTableResult['TotalRecordCount'] = $recordCount;
        $jTableResult['Records'] = $final_rows;
        print json_encode($jTableResult);
        exit();
    }
    
    public function cml_referrals() {
        
        if( $_GET['action'] == 'edit' && is_numeric( $_REQUEST['id'] ) ) { 
            $id = $_REQUEST['id'];
            if( isset($_POST['btnsave']) && $_POST['btnsave'] != "" ) {
                $exclude = array('btnsave','id','btnback','filtered_form');
                foreach ($_POST as $k=>$v) {
                    if(in_array($k, $exclude)) {
                        unset($_POST[$k]);
                    }
                }
                
                $this->cml_update_record("cml_invitations", $_POST, "id = '".$id."'");
                $message = 'Status updated successfully';
            }
            $invitation = $this->cml_get_data("cml_invitations", "id = '".$id."'", true);
            $attr = array();
            $attr['invitation'] = $invitation;
            $attr['id'] = $id;
            $attr['message'] = $message;
            $html = $this->cml_load_template( "edit_referral", "admin", $attr );
            echo $html;
        }else{
            if( $_GET['action'] == 'del' && is_numeric( $_REQUEST['id'] ) ){
                $id = $_REQUEST['id'];
                $this->cml_del_record("cml_invitations", "id = '".$id."'");
            }elseif ($_GET['action'] == 'del' && $_REQUEST['ids'] != "" ){
                $ids = explode(",", $_REQUEST['ids']);
                if(is_array($ids)) {
                    foreach($ids as $id) {
                        if(is_numeric($id)) {
                            $this->cml_del_record("cml_invitations", "id = '".$id."'");
                        }
                    }
                }
            }
            wp_enqueue_script( 'cml_jtable_js' );
            wp_enqueue_style( 'cml_jtable_css' );
            $attr = $_REQUEST;
            $html = $this->cml_load_template( "referrals", "admin", $attr );
            echo $html;
        }
    }
    
    public function cml_restrict_admin_pages() {
        
        $screen = get_current_screen();
        $access_only = $this->cml_user_admin_screens();
        if(is_array($access_only) && sizeof($access_only)>0) {
            if(!in_array($screen->id, $access_only)) {
                $page_to_redirect = str_replace(array("arforms_page_","toplevel_page_"), "", $access_only[0]);
                wp_redirect( admin_url( 'admin.php?page='.$page_to_redirect ) );
                exit;
            }
        }
    }
    
    public function cml_update_text( $translation, $text, $domain ) {
        
        global $cml_lang;
        
        if($domain=='ARForms' && strtolower($text)=='entries list') {
            $translation = $cml_lang['reports_lists_label'];
        }
        if($domain=='ARForms' && strtolower($text)=='select form') {
            $translation = $cml_lang['reports_select_label'];
        }
        if($domain=='ARForms' && strtolower($text)=='form entries') {
            $translation = $cml_lang['reports_entries_label'];
        }
        return $translation;
    }
    
    public function cml_update_menu_labels() {
        global $menu, $submenu, $cml_lang;
        
        foreach( $submenu as $menu_key=>$menu_items ) {
            if($menu_key=='ARForms') {
                foreach($menu_items as $index=>$menu_item) {
                    if($menu_item[0]=='Form Entries') {
                        $submenu[$menu_key][$index][0] = $cml_lang['reports_lists_label'];
                        $submenu[$menu_key][$index][3] = 'ARForms | '.$cml_lang['reports_lists_label'];
                        break;
                    }
                }
                break;
            }
        }
        $user_menu = $this->cml_user_admin_menu();
        if(!empty($user_menu) && is_array($user_menu)) {
            $menu_items_keep = array();
            foreach( $user_menu as $user_menu_k=>$user_menu_v) {
                foreach( $menu as $menu_key=>$menu_detail ) {
                    if($menu_detail[0]==$user_menu_k || $menu_detail[1]==$user_menu_k) {
                        $menu_items_keep[] = $menu_key;
                    }
                }
            }
            foreach( $menu as $menu_key=>$menu_detail ) {
                if(!in_array($menu_key, $menu_items_keep)) {
                    unset($menu[$menu_key]);
                }
            }
            foreach( $user_menu as $user_menu_k=>$user_menu_v) {            
                $submenu_items_keep = array();
                foreach( $submenu[$user_menu_k] as $menu_key=>$menu_detail ) {
                    if(in_array($menu_detail[1],$user_menu_v) && $menu_detail[2]!='arm_documentation') {
                        $submenu_items_keep[] = $menu_key;
                    }
                }
                foreach( $submenu[$user_menu_k] as $menu_key=>$menu_detail ) {
                    if(!in_array($menu_key, $submenu_items_keep)) {
                        unset($submenu[$user_menu_k][$menu_key]);
                    }
                }
            }
        }
    }
    
    public function cml_retrieve_form_entry() {
        
        if(empty($_REQUEST['data']) && is_array($_POST)) {
            $data = array('aoData'=>$_POST);
            $_REQUEST['data'] = json_encode($data);             
            $this->cml_arf_retrieve_form_entry();                    
        }
    }
    
    public function cml_arf_retrieve_form_entry(){
        global $wpdb, $MdlDb, $arffield, $armainhelper, $db_record, $arfform,$arfpagesize;
        
        $requested_data = json_decode(stripslashes_deep($_REQUEST['data']),true);
        
        $filtered_aoData = $requested_data['aoData'];
        
        $form_id = isset($filtered_aoData['form']) ? $filtered_aoData['form'] : '-1';
        $start_date = isset($filtered_aoData['start_date']) ? $filtered_aoData['start_date'] : '';
        $end_date = isset($filtered_aoData['end_date']) ? $filtered_aoData['end_date'] : '';
        $start_date = isset($_COOKIE['start_time']) ? $start_date.$_COOKIE['start_time'] : $start_date;
        $end_date = isset($_COOKIE['end_time']) ? $end_date.$_COOKIE['end_time'] : $end_date;

        $return_data = array();

        $form_select = $wpdb->get_row( $wpdb->prepare("SELECT * FROM `".$MdlDb->forms."` WHERE `id` = %d AND `is_template` != %d AND `status` = %s", $form_id, 1,'published') );
        
        
        $form_name = $form_select->name;

        $form_css = maybe_unserialize($form_select->form_css);

        $form_options = maybe_unserialize($form_select->options);

        $arffieldorder = array();

        if(isset($form_options['arf_field_order']) && $form_options['arf_field_order'] != ''){
            $arffieldorder = json_decode($form_options['arf_field_order'], true);
            asort($arffieldorder);
        }

        $offset = isset($filtered_aoData['iDisplayStart']) ? $filtered_aoData['iDisplayStart'] : 0;
        $limit = isset($filtered_aoData['iDisplayLength']) ? $filtered_aoData['iDisplayLength'] : 10;

        $searchStr = isset($filtered_aoData['sSearch']) ? $filtered_aoData['sSearch'] : '';
        $sorting_order = isset($filtered_aoData['sSortDir_0']) ? $filtered_aoData['sSortDir_0'] : 'desc';
        $sorting_column = (isset($filtered_aoData['iSortCol_0']) && $filtered_aoData['iSortCol_0'] > 0) ? $filtered_aoData['iSortCol_0'] : 1;

        $form_cols = $wpdb->get_results( $wpdb->prepare("SELECT * FROM `".$MdlDb->fields."` WHERE form_id = %d AND type NOT IN ('divider', 'captcha', 'break', 'html', 'imagecontrol')", $form_id) );

        if(count($arffieldorder) > 0){
            $form_cols_temp = array();
            foreach ($arffieldorder as $fieldkey => $fieldorder) {
                foreach ($form_cols as $frmoptkey => $frmoptarr) {
                    if($frmoptarr->id == $fieldkey){
                        $form_cols_temp[] = $frmoptarr;
                        unset($form_cols[$frmoptkey]);
                    }
                }
            }

            if(count($form_cols_temp) > 0) {
                if(count($form_cols) > 0) {
                    $form_cols_other = $form_cols;
                    $form_cols = array_merge($form_cols_temp,$form_cols_other);
                } else {
                    $form_cols = $form_cols_temp;
                }
            }
        }

        global $style_settings, $wp_scripts;
        $wp_format_date = get_option('date_format');

        if ($wp_format_date == 'F j, Y' || $wp_format_date == 'm/d/Y') {
            $date_format_new = 'mm/dd/yy';
        } else if ($wp_format_date == 'd/m/Y') {
            $date_format_new = 'dd/mm/yy';
        } else if ($wp_format_date == 'Y/m/d') {
            $date_format_new = 'dd/mm/yy';
        } else {
            $date_format_new = 'mm/dd/yy';
        }
        $new_start_date = $start_date;
        $new_end_date = $end_date;
        $show_new_start_date = $new_start_date;
        $show_new_end_date = $new_end_date;

        $arf_db_columns = array('0' => '', '1' => 'id');

        $form_cols = apply_filters('arfpredisplayformcols', $form_cols, $form_id);

        $arf_sorting_array = array();

        if (count($form_cols) > 0) {
            for ($col_i = 2; $col_i <= count($form_cols) + 1; $col_i++) {
                $col_j = $col_i - 2;
                $arf_db_columns[$col_i] = $armainhelper->truncate($form_cols[$col_j]->name, 40);
                $arf_sorting_array[$form_cols[$col_j]->id] = $col_i;
            }
            $arf_db_columns[$col_i] = 'entry_key';
            $arf_db_columns[$col_i + 1] = 'created_date';
            $arf_db_columns[$col_i + 2] = 'browser_info';
            $arf_db_columns[$col_i + 3] = 'ip_address';
            $arf_db_columns[$col_i + 4] = 'country';
            $arf_db_columns[$col_i + 5] = 'Page URL';
            $arf_db_columns[$col_i + 6] = 'Referrer URL';
            $arf_db_columns[$col_i + 7] = 'Action';

        } else {
            $arf_db_columns['2'] = 'entry_key';
            $arf_db_columns['3'] = 'created_date';
            $arf_db_columns['4'] = 'browser_info';
            $arf_db_columns['5'] = 'ip_address';
            $arf_db_columns['6'] = 'country';
            $arf_db_columns['7'] = 'Page URL';
            $arf_db_columns['8'] = 'Referrer URL';
            $arf_db_columns['9'] = 'Action';
        }

        $arforderbycolumn = isset($arf_db_columns[$sorting_column]) ? $arf_db_columns[$sorting_column] : 'id';
        $item_order_by = " ORDER BY it.$arforderbycolumn $sorting_order";

        $where_clause = "it.form_id=".$form_id;

        if ($new_start_date != '' and $new_end_date != '') {
            if ($date_format_new == 'dd/mm/yy') {
                $new_start_date = str_replace('/', '-', $new_start_date);
                $new_end_date = str_replace('/', '-', $new_end_date);
            }
            $new_start_date_var = date('Y-m-d H:i:s', strtotime($new_start_date));

            $new_end_date_var = date('Y-m-d H:i:s', strtotime($new_end_date));

            $where_clause .= " and DATE(it.created_date) >= '" . $new_start_date_var . "' and DATE(it.created_date) <= '" . $new_end_date_var . "'";
        } else if ($new_start_date != '' and $new_end_date == '') {
            if ($date_format_new == 'dd/mm/yy') {
                $new_start_date = str_replace('/', '-', $new_start_date);
            }
            $new_start_date_var = date('Y-m-d H:i:s', strtotime($new_start_date));

            $where_clause .= " and DATE(it.created_date) >= '" . $new_start_date_var . "'";
        } else if ($new_start_date == '' and $new_end_date != '') {
            if ($date_format_new == 'dd/mm/yy') {
                $new_end_date = str_replace('/', '-', $new_end_date);
            }
            $new_end_date_var = date('Y-m-d H:i:s', strtotime($new_end_date));

            $where_clause .= " and DATE(it.created_date) <= '" . $new_end_date_var . "'";
        }
        global $cml_options;
        $all_entries = $wpdb->get_results("SELECT * FROM `".$MdlDb->entries."` it WHERE ".$where_clause);
        $entries_ids = array();
        foreach($all_entries as $entry) {
            $entries_ids[] = $entry->id;
        }
        $entries_values = $this->cml_get_data("arf_entry_values","entry_id IN(".implode(",", $entries_ids).")");
        $form_entries_values = array();
        foreach($entries_values as $entry_value) {            
            $form_entries_values[$entry_value->entry_id."_".$entry_value->field_id] = str_replace("$", "", $entry_value->entry_value);
        }
        
        $sweepscoach_total = $royale_total = 0;
        foreach($entries_values as $entry_value) {    
            if($entry_value->field_id==$cml_options['sweepscoach_royal_field']) {
                $field_index = $entry_value->entry_id."_".$cml_options['price_text_field'];                
                if(strpos($entry_value->entry_value,$cml_options['sweepscoach_text_match'])!==FALSE){
                    $sweepscoach_total = $sweepscoach_total+(1*$form_entries_values[$field_index]);
                }elseif(strpos($entry_value->entry_value,$cml_options['royale_text_match'])!==FALSE) {
                    $royale_total = $royale_total+(1*$form_entries_values[$field_index]);
                }
            }
        }
        
        $total_records = $wpdb->get_var("SELECT count(*) as total_entries FROM `".$MdlDb->entries."` it WHERE ".$where_clause);
        
        $item_order_by .= " LIMIT {$offset},{$limit}";
        if( isset($arf_sorting_array) && !empty($arf_sorting_array) && in_array($sorting_column,$arf_sorting_array) ){
            $temp_items = $db_record->getPage('', '', $where_clause, '', $searchStr, $arffieldorder);
            $temp_field_metas = array();
            $sorting_value = array_search($sorting_column, $arf_sorting_array);
            foreach( $temp_items as $K => $I ){
                foreach( $arf_sorting_array as $a => $b ){
                    $temp_field_metas[$K][$a] = $I->metas[$a];
                    $temp_field_metas[$K]['sorting_column'] = $sorting_value;
                }
            }
                        
            if( $sorting_order == 'asc' ){
                uasort( $temp_field_metas, function($a, $b){
                    $sort_on = $a['sorting_column'];
                    return strnatcasecmp($a[$sort_on],$b[$sort_on]);
                });
            } else {
                uasort( $temp_field_metas, function($a, $b){
                    $sort_on = $a['sorting_column'];
                    return strnatcasecmp($b[$sort_on],$a[$sort_on]);
                });
            }
            $sorted_columns = array();
            $counter = 0;

            foreach( $temp_field_metas as $c => $d ){
            	$sorted_columns[$c] = $temp_items[$c];
                $counter++;
            }
            $sorted_cols = array_chunk($sorted_columns, $limit);

            $chuncked_array_key = ceil($offset / $limit) + 1;

            $chunk_key = $chuncked_array_key - 1;
            $items = $sorted_cols[$chunk_key];

        } else {

            $items = $db_record->getPage('', '', $where_clause, $item_order_by, $searchStr, $arffieldorder);
        }

        $action_no = 0;

        if( is_rtl() ){
            $divStyle = "display:inline-block;position:relative;";
        } else {
            $divStyle = "position:relative;width:100%;text-align:center;";
        }

        $default_hide = array(
            '0' => '<div style="'.$divStyle.'"><div class="arf_custom_checkbox_div arfmarginl15"><div class="arf_custom_checkbox_wrapper arfmargin10custom"><input id="cb-select-all-1" type="checkbox" class=""><svg width="18px" height="18px">'.ARF_CUSTOM_UNCHECKED_ICON.'
                                '.ARF_CUSTOM_CHECKED_ICON.'</svg></div></div>
            <label for="cb-select-all-1"  class="cb-select-all"><span class="cb-select-all-checkbox"></span></label></div>',
            '1' => 'ID'
        );

        $items = apply_filters('arfpredisplaycolsitems', $items, $form_id);

        if (count($form_cols) > 0) {
            for ($i = 2; $i <= count($form_cols) + 1; $i++) {
                $j = $i - 2;
                $default_hide[$i] = $armainhelper->truncate($form_cols[$j]->name, 40);
            }
            $default_hide[$i] = 'Entry key';
            $default_hide[$i + 1] = 'Entry Creation Date';
            $default_hide[$i + 2] = 'Browser Name';
            $default_hide[$i + 3] = 'IP Address';
            $default_hide[$i + 4] = 'Country';
            $default_hide[$i + 5] = 'Page URL';
            $default_hide[$i + 6] = 'Referrer URL';
            $default_hide[$i + 7] = 'Action';

            $action_no = $i + 7;
        } else {
            $default_hide['2'] = 'Entry Key';
            $default_hide['3'] = 'Entry creation date';
            $default_hide['4'] = 'Browser Name';
            $default_hide['5'] = 'IP Address';
            $default_hide['6'] = 'Country';
            $default_hide['7'] = 'Page URL';
            $default_hide['8'] = 'Referrer URL';
            $default_hide['9'] = 'Action';
            $action_no = 9;
        }


        $columns_list_res = $wpdb->get_results($wpdb->prepare('SELECT columns_list FROM ' . $MdlDb->forms . ' WHERE id = %d', $form_id), ARRAY_A);

        $columns_list_res = $columns_list_res[0];

        $columns_list = maybe_unserialize($columns_list_res['columns_list']);

        $is_colmn_array = is_array($columns_list);

        $exclude = '';

        $exclude_array = array();

        if (count($columns_list) > 0 and $columns_list != '') {

            foreach ($columns_list as $keys => $column) {

                foreach ($default_hide as $key => $val) {

                    if ($column == $val) {
                        if ($exclude_array == "") {
                            $exclude_array[] = $key;
                        } else {
                            if (!in_array($key, $exclude_array)) {
                                $exclude_array[] = $key;

                                $exclude_no++;
                            }
                        }
                    }
                }
            }
        }

        $ipcolumn = ($action_no - 4);
        $page_url_column = ($action_no - 2);
        $referrer_url_column = ($action_no - 1);

        if ($exclude_array == "" and ! $is_colmn_array) {
            $exclude_array = array($ipcolumn, $page_url_column, $referrer_url_column);
        } else if (is_array($exclude_array) and ! $is_colmn_array) {

            if (!in_array($ipcolumn, $exclude_array)) {
                array_push($exclude_array, $ipcolumn);
            }
            if (!in_array($page_url_column, $exclude_array)) {
                array_push($exclude_array, $page_url_column);
            }
            if (!in_array($referrer_url_column, $exclude_array)) {
                array_push($exclude_array, $referrer_url_column);
            }
        }

        if ($exclude_array != "") {
            $exclude = implode(",", $exclude_array);
        }

        if ($wp_format_date == 'F j, Y' || $wp_format_date == 'm/d/Y') {
            $date_format_new = 'MM/DD/YYYY';
            $date_format_new1 = 'MM-DD-YYYY';
            $start_date_new = '01/01/1970';
            $end_date_new = '12/31/2050';
        } else if ($wp_format_date == 'd/m/Y') {
            $date_format_new = 'DD/MM/YYYY';
            $date_format_new1 = 'DD-MM-YYYY';
            $start_date_new = '01/01/1970';
            $end_date_new = '31/12/2050';
        } else if ($wp_format_date == 'Y/m/d') {
            $date_format_new = 'DD/MM/YYYY';
            $date_format_new1 = 'DD-MM-YYYY';
            $start_date_new = '01/01/1970';
            $end_date_new = '31/12/2050';
        } else {
            $date_format_new = 'MM/DD/YYYY';
            $date_format_new1 = 'MM-DD-YYYY';
            $start_date_new = '01/01/1970';
            $end_date_new = '12/31/2050';
        }

        $data = array();

        if( count($items) > 0 ){
            $arrecordcontroller = new arrecordcontroller();
            global $arrecordhelper;
            $ai = 0;
            $arf_edit_select_array = array();
            foreach ($items as $key => $item) {
                if( is_rtl() ){
                    $divStyle = "display:inline-block;position:relative;";
                } else {
                    $divStyle = "position:relative;width:100%;text-align:center;";
                }
                $data[$ai][0] = "<div class='DataTables_sort_wrapper'><div style='{$divStyle}'>
                       <div class='arf_custom_checkbox_div arfmarginl15'><div class='arf_custom_checkbox_wrapper'><input id='cb-item-action-{$item->id}' class='' type='checkbox' value='{$item->id}' name='item-action[]' />
                                        <svg width='18px' height='18px'>
                                        ".ARF_CUSTOM_UNCHECKED_ICON."
                                        ".ARF_CUSTOM_CHECKED_ICON."
                                        </svg>
                                    </div>
                                </div>
                    <label for='cb-item-action-{$item->id}'><span></span></label></div></div>";
                $data[$ai][1] = $item->id;
                $ni = 2;
                foreach ($form_cols as $col) {
                    $field_value = isset($item->metas[$col->id]) ? $item->metas[$col->id] : false;
                    if( !is_array($col->field_options) ){
                        $col->field_options = json_decode($col->field_options,true);
                    }

                    if( !is_array($col->options) ){
                        $col->options = json_decode($col->options,true);
                    }
                    
                    if ($col->type == 'checkbox' || $col->type == 'radio' || $col->type == 'select') {
                        if (isset($col->field_options['separate_value']) && $col->field_options['separate_value'] == '1') {
                            $option_separate_value = array();

                            foreach ($col->options as $k => $options) {
                                $option_separate_value[] = array('value' => htmlentities($options['value']), 'text' => $options['label']);
                            }
                            $arf_edit_select_array[] = array($col->id => json_encode($option_separate_value, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP));
                        } else {
                            $option_value = '';
                            $option_value = array();
                            if(is_array($col->options))
                            {
                                foreach ($col->options as $k => $options) {
                                    if (is_array($options)) {
                                        $option_value[] = ($options['label']);
                                    } else {
                                        $option_value[] = ($options);
                                    }
                                }
                            }
                            $arf_edit_select_array[] = array($col->id => json_encode($option_value, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP));
                        }
                    }
                    
                    $data[$ai][$ni] = $arrecordhelper->display_value($field_value, $col, array('type' => $col->type, 'truncate' => true, 'attachment_id' => $item->attachment_id, 'entry_id' => $item->id),$form_css);
                    $ni++;
                }
                
                $data[$ai][$ni] = $item->entry_key;
                $data[$ai][$ni + 1] = date(get_option('date_format'), strtotime($item->created_date));
                $browser_info = $arrecordcontroller->getBrowser($item->browser_info);
                $data[$ai][$ni + 2] = $browser_info['name'] . ' (Version: ' . $browser_info['version'] . ')';
                $data[$ai][$ni + 3] = $item->ip_address;
                $data[$ai][$ni + 4] = $item->country;
                $http_referrer = unserialize($item->description);
                $data[$ai][$ni + 5] = $http_referrer['page_url'];
                $data[$ai][$ni + 6] = $http_referrer['http_referrer'];

                $view_entry_icon = is_rtl() ? 'view_icon23_rtl.png' : 'view_icon23.png';
                $view_entry_icon_hover = is_rtl() ? 'view_icon23_hover_rtl.png' : 'view_icon23_hover.png';

                $view_entry_btn = "<div class='arfformicondiv arfhelptip' title='" . addslashes(__('Preview', 'ARForms')) . "'><a href='javascript:void(0);'  onclick='open_entry_thickbox({$item->id},\"".htmlentities($form_name, ENT_QUOTES)."\");'><svg width='30px' height='30px' viewBox='-3 -8 32 32' class='arfsvgposition'><path xmlns='http://www.w3.org/2000/svg' fill-rule='evenodd' clip-rule='evenodd' fill='#ffffff' d='M12.993,15.23c-7.191,0-11.504-7.234-11.504-7.234  S5.801,0.85,12.993,0.85c7.189,0,11.504,7.19,11.504,7.19S20.182,15.23,12.993,15.23z M12.993,2.827  c-5.703,0-8.799,5.214-8.799,5.214s3.096,5.213,8.799,5.213c5.701,0,8.797-5.213,8.797-5.213S18.694,2.827,12.993,2.827z   M12.993,11.572c-1.951,0-3.531-1.581-3.531-3.531s1.58-3.531,3.531-3.531c1.949,0,3.531,1.581,3.531,3.531  S14.942,11.572,12.993,11.572z'/></svg></a></div>";

                global $PDF_button;
                do_action('arf_additional_action_entries', $item->id, $form_id,true);
                global $PDF_button;
                
                $id = $item->id;

                $delete_entry_icon = is_rtl() ? 'delete_icon223_rtl.png' : 'delete_icon223.png';
                $delete_entry_icon_hover = is_rtl() ? 'delete_icon223_hover_rtl.png' : 'delete_icon223_hover.png';

                $delete_entry_btn = "<div class='arfformicondiv arfhelptip arfentry_delete_div_".$item->id."' title='" . addslashes(__('Delete', 'ARForms')) . "'><a data-id='".$item->id."' id='arf_delete_single_entry' style='cursor:pointer'><svg width='30px' height='30px' viewBox='-5 -5 32 32' class='arfsvgposition'><path xmlns='http://www.w3.org/2000/svg' fill-rule='evenodd' clip-rule='evenodd' fill='#ffffff' d='M18.435,4.857L18.413,19.87L3.398,19.88L3.394,4.857H1.489V2.929  h1.601h3.394V0.85h8.921v2.079h3.336h1.601l0,0v1.928H18.435z M15.231,4.857H6.597H5.425l0.012,13.018h10.945l0.005-13.018H15.231z   M11.4,6.845h2.029v9.065H11.4V6.845z M8.399,6.845h2.03v9.065h-2.03V6.845z' /></svg></a></div>";

                $delete_entry_overlay = "<div id='view_entry_detail_container_{$item->id}' style='display:none;'>" . $arrecordcontroller->get_entries_list_edit($item->id,$arffieldorder) . "</div><div style='clear:both;' class='arfmnarginbtm10'></div>";

                $data[$ai][$ni + 7] = "<div class='arf-row-actions'>{$view_entry_btn}{$PDF_button}{$delete_entry_btn} {$delete_entry_overlay} <input type='hidden' id='arf_edit_select_array_one' value='" . json_encode($arf_edit_select_array) . "' /></div>";
                $data[$ai][$ni + 7] .= "<input type='hidden' id='arf_edit_select_array_{$item->id}' value='".json_encode($arf_edit_select_array)."' /><script>cml_populate_total('".sprintf('%0.2f', $sweepscoach_total)."','".sprintf('%0.2f', $royale_total)."');</script>";
                
                $PDF_button = '';
                $action_no = $ni + 7;
                $ai++;
            }
            
            $sEcho = isset($filtered_aoData['sEcho']) ? intval($filtered_aoData['sEcho']) : intval(10);

            $return_data = array(
                'sEcho' => $sEcho,
                'iTotalRecords' => (int)$total_records,
                'iTotalDisplayRecords' => (int)$total_records,
                'aaData' => $data,
            );

        } else {
            $sEcho = isset($filtered_aoData['sEcho']) ? intval($filtered_aoData['sEcho']) : intval(10);
            $return_data = array(
                'sEcho' => $sEcho,
                'iTotalRecords' => (int)$total_records,
                'iTotalDisplayRecords' => (int)$total_records,
                'aaData' => $data,
            );
        }

        echo json_encode( $return_data );

        die;
    }
    
    /*
     * Save Username for the member
     * Required Param: user_name, member_id
     */
    
    public function cml_save_username() {
        
        global $cml_lang;
        
        $error = false;
        $message = '';
        $member_id = $_POST['member_id'];
        $user_name = $_POST['user_name'];
        if( !current_user_can('editor') && !current_user_can('administrator') ) {
            $error = true;
            $message = $cml_lang['err_user_not_authorized'];
        }
        
        if( !$error && empty($user_name) ) {
            $error = true;
            $message = $cml_lang['err_user_name_empty'];
        }
        
        if( !$error && empty($member_id) ) {
            $error = true;
            $message = $cml_lang['err_member_id_empty'];
        }
        
        if( !$error ) {
            $member_data = $this->cml_get_data("arm_members","arm_member_id = '".$member_id."'",true);
            if(!$member_data) {
                $error = true;
                $message = $cml_lang['err_member_not_exists'];
            }
        }
        
        if( !$error ) {
            $user_id = $member_data->arm_user_id;
            $user = get_user_by("id",$user_id);
            if(!$user) {
                $error = true;
                $message = $cml_lang['err_user_not_exists'];
            }
        }
        
        if( !$error ) {
            $data = array();
            $data['arm_user_login']     = $user_name;
            $data['arm_user_nicename']  = $user_name;
            $this->cml_update_record( "arm_members", $data, "arm_member_id = '".$member_id."'" );
            $data = array();
            $data['user_login']     = $user_name;
            $data['user_nicename']  = $user_name;
            $this->cml_update_record( "users", $data, "ID = '".$user_id."'" );
            update_user_meta($user_id,'nickname',$user_name);
            $message = $cml_lang['msg_user_name_updated'];
        }
        
        $return = array( 'error' => $error, 'message'=> $message );
            
        header('Content-Type: application/json');
        echo json_encode($return);
        exit();
    }
    
    /*
     * Plugin settings page.
     * Will save all settings of the plugin 
     */
    
    public function cml_settings() {
        global $cml_options, $cml_lang;
        do_action('cml_before_settings', $this, $cml_options );
        
        if( isset($_POST['btnsave']) && $_POST['btnsave'] != "" ) {            
            $exclude = array('btnsave');
            $cml_options = array();            
            foreach( $_POST as $k => $v ) {
                if( !in_array( $k, $exclude )) {
                    if(!is_array($v)) {
                        $val = $this->make_safe($v);
                    }else{
                        $val = $v;
                    }
                    $cml_options[$k] = $val;
                }                
            }            
            update_option( 'cml_settings', $cml_options );
            $message = $this->cml_get_message_html( $cml_lang['settings_save_message'], 'message' );
        }
        
        $arforms = $this->cml_get_data("arf_forms", "is_template !='1' AND status = 'published'");
        $arforms_fields = $this->cml_get_data("arf_fields", "name !='' AND type NOT IN('divider','break')");
        $blogusers = get_users('role=administrator');
        $current_user = wp_get_current_user();
        $attr = $cml_options;
        $attr['message']        = $message;
        $attr['arforms']        = $arforms;
        $attr['users']          = $blogusers;
        $attr['current_user_id']= $current_user->ID;
        $attr['arforms_fields'] = $arforms_fields;
        $html = $this->cml_load_template( "settings", "admin", $attr );
        do_action('cml_after_settings', $this, $cml_options );
        echo $html;
    }
}

$cml_admin = new CML_Admin();