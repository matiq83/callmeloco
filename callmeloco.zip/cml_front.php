<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */

/**
 * Class that will hold functionality for front side
 *
 * PHP version 5
 *
 * @category   Front Side Code
 * @package    CallMeLoco Customization
 * @author     Muhammad Atiq
 * @version    1.0.0
 * @since      File available since Release 1.0.0
*/

class CML_Front extends CML
{
    //Front side starting point. Will call appropriate front side hooks
    public function __construct() {
        
        do_action('cml_before_front', $this );
        //All front side code will go here
        
        add_shortcode( 'cml_invite_friends', array( $this, 'cml_invite_friends' ) );
        add_shortcode( 'cml_invited_friends_log', array( $this, 'cml_invited_friends_log' ) );
        add_action( 'template_redirect', array( $this, 'cml_template_redirect' ) );
        add_action( 'wp_ajax_cml_send_invite_friend_mail', array( $this, 'cml_send_invite_friend_mail' ) );
        add_action( 'wp_ajax_nopriv_cml_send_invite_friend_mail', array( $this, 'cml_send_invite_friend_mail' ) );        
        add_action( 'wp_ajax_cml_send_sms', array( $this, 'cml_send_sms' ) );
        add_action( 'wp_ajax_nopriv_cml_send_sms', array( $this, 'cml_send_sms' ) );        
        add_action( 'wp_ajax_cml_update_user_sweepstakes', array( $this, 'cml_update_user_sweepstakes' ) );
        add_action( 'wp_ajax_nopriv_cml_update_user_sweepstakes', array( $this, 'cml_update_user_sweepstakes' ) );        
        add_action( 'arfaftercreateentry', array( $this, 'cml_arfaftercreateentry' ),10, 2);
        
        do_action('cml_after_front', $this );
    }
    
    public function cml_invited_friends_log() {
        $html = '';
        $current_user = wp_get_current_user();
        if( $current_user->ID == 0 ) {
            return $html;
        }
        $invitations = $this->cml_get_data("cml_invitations", "inviter = '".$current_user->ID."'");
        if( empty($invitations) ) {
            return $html;
        }
        $attr = array();
        $attr['invitations'] = $invitations;
        $html = $this->cml_load_template( "cml_invited_friends_log", "front", $attr );
        return $html;
    }
    
    public function cml_arfaftercreateentry($entry_id, $form_id) {
        global $cml_options, $cml_lang;
        $order_form = $cml_options['arf_payment_form'];
        if($order_form==$form_id) {
            $price_row = $this->cml_get_data("arf_entry_values", "entry_id = '".$entry_id."' AND field_id = '".$cml_options['price_text_field']."'", true);
            //$field_phone = $this->cml_get_data("arf_fields", "type = 'phone' AND form_id = '".$form_id."'",true);
            $phone_row = $this->cml_get_data("arf_entry_values", "entry_id = '".$entry_id."' AND field_id = '".$cml_options['phone_field']."'", true);
            //$field_email = $this->cml_get_data("arf_fields", "type = 'email' AND form_id = '".$form_id."'",true);
            $email_row = $this->cml_get_data("arf_entry_values", "entry_id = '".$entry_id."' AND field_id = '".$cml_options['email_field']."'", true);
            
            $already_rewarded = $this->cml_get_data("cml_invitations","(invited = '".$phone_row->entry_value."' OR invited = '".$email_row->entry_value."') AND invited_browser != ''", true);
            if(!$already_rewarded) {
                if(!empty($phone_row) || !empty($email_row)) {
                    $current_user = wp_get_current_user();
                    $invited_ip = $this->cml_get_client_ip();
                    $browser = $this->cml_get_browser_name();
                    $current_timestamp = strtotime('now');
                    $invited_country = $this->cml_ip_info($invited_ip,'Country');

                    $invitations = $this->cml_get_data("cml_invitations","(invited = '".$phone_row->entry_value."' OR invited = '".$email_row->entry_value."') AND invited_browser=''");
                    if(!empty($invitations)) {
                        foreach ($invitations as $invitation) {
                            if(empty($_COOKIE['cml_invite_id']) || $_COOKIE['cml_invite_id']==$invitation->id) {                    
                                $data = array(); 
                                $data['invited_id'] = $current_user->ID;
                                $data['invited_browser'] = $browser['name'];
                                $data['invited_platform'] = ucwords($browser['platform']);
                                $data['invited_ip'] = $invited_ip;
                                $data['invited_country'] = $invited_country;
                                $data['amount_paid'] = $price_row->entry_value;
                                $data['date_time'] = $current_timestamp;
                                $this->cml_update_record("cml_invitations", $data, "id = '".$invitation->id."'");
                                $invitation = $this->cml_get_data("cml_invitations","id = '".$invitation->id."'", TRUE);
                                $this->cml_send_admin_invitation_notification($invitation, $price_row, $phone_row, $email_row, $entry_id, $form_id);
                            }
                        }                    
                    }elseif(!empty ($_COOKIE['cml_inviter_id']) && is_numeric($_COOKIE['cml_inviter_id'])){
                        $inviter_id = $_COOKIE['cml_inviter_id'];
                        $inviter_browser = get_user_meta( $inviter_id, 'cml_user_browser', true );
                        $inviter_platform = get_user_meta( $inviter_id, 'cml_user_platform', true);
                        $inviter_ip = get_user_meta( $inviter_id, 'cml_user_ip', true );
                        $inviter_country = get_user_meta( $inviter_id, 'cml_user_country', true);

                        $data = array();
                        $data['inviter'] = $inviter_id;
                        $data['inviter_browser'] = $inviter_browser;
                        $data['inviter_platform'] = $inviter_platform;
                        $data['inviter_ip'] = $inviter_ip;
                        $data['inviter_country'] = $inviter_country;
                        $data['invited'] = ($email_row->entry_value!="")?$email_row->entry_value:$phone_row->entry_value;
                        $data['invited_id'] = $current_user->ID;
                        $data['invited_browser'] = $browser['name'];
                        $data['invited_platform'] = ucwords($browser['platform']);
                        $data['invited_ip'] = $invited_ip;
                        $data['invited_country'] = $invited_country;
                        $data['amount_paid'] = $price_row->entry_value;
                        $data['date_time_created'] = $current_timestamp;
                        $data['date_time'] = $current_timestamp;
                        $data['status'] = 'Sent';
                        $lastid = $this->cml_add_record("cml_invitations", $data);
                        $invitation = $this->cml_get_data("cml_invitations","id = '".$lastid."'", TRUE);
                        $this->cml_send_admin_invitation_notification($invitation, $price_row, $phone_row, $email_row, $entry_id, $form_id);
                    }   
                }
            }
        }
    }
    
    public function cml_send_admin_invitation_notification( $invitation, $price_row, $phone_row, $email_row, $entry_id, $form_id ) {
        global $cml_lang, $cml_options;
        if(empty($invitation) || empty($entry_id)) {
            return false;
        }
        
        $attr = array();        
        $inviter_detail = get_userdata($invitation->inviter);
        $invited_detail = get_userdata($invitation->invited_id);
        $attr['invitation'] = $invitation;
        $attr['inviter_detail'] = $inviter_detail;
        $attr['invited_detail'] = $invited_detail;
        $attr['price_row'] = $price_row;
        $attr['phone_row'] = $phone_row;
        $attr['email_row'] = $email_row;
        $body = $this->cml_load_template( "admin_invitation_email_template", "front", $attr );
        $subject = $cml_lang['admin_invitation_mail_subject'];
        $to = $cml_options['referral_admin_email'];
        $headers = array();
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $headers[] = 'From: '.CML_SITE_NAME.' <info@callmeloco.com>';
        
        wp_mail( $to, $subject, $body, $headers );            
    }
    
    public function cml_update_user_sweepstakes() {
        
        $current_user = wp_get_current_user();
        if( $current_user->ID == 0 ) {
            exit();
        } 
        
        update_user_meta( $current_user->ID, 'cml_sweepstakes', $_REQUEST['sweepstakes'] );
        echo 'Done';
        exit();
    }
    
    public function cml_template_redirect() {
        
        if($_REQUEST['cml_load_email_preview']=='yes') {
            $html = $this->cml_get_invite_friends_email_template();
            echo $html;exit();
        }
        if($_REQUEST['cml_get_gmail_contacts']=='yes') {
            $html = $this->cml_get_contacts_data();
            echo $html;exit();
        }
        if($_REQUEST['cml_send_sms']=='yes') {
            $html = $this->cml_get_send_sms_html();
            echo $html;exit();
        }
        if(!empty($_REQUEST['cmluid']) || !empty($_REQUEST['cmlid'])){
            $current_user = wp_get_current_user();
            if( $current_user->ID == 0 ) {
                $this->redirect(CML_REGISTRATION_URL);
            }
        }
    }
    
    public function cml_get_invite_friends_email_template() {
        $html = '';
        $current_user = wp_get_current_user();
        if( $current_user->ID == 0 ) {
            return $html;
        }  
        //$current_user = get_userdata(2);
        $invite_url  = CML_SITE_BASE_URL.'?cmluid='.base64_encode($current_user->ID);
        $user_name = $current_user->display_name;
        if(!empty($current_user->user_firstname)){
            $user_name = trim($current_user->user_firstname.' '.$current_user->user_lastname);
        }
        $attr = array();
        $attr['header_bg'] = CML_PLUGIN_URL."images/logo.png";
        $attr['thanks_img'] = CML_PLUGIN_URL."images/thanks.png";
        $attr['arroq_img'] = CML_PLUGIN_URL."images/arrow_click.png";
        $attr['user_avatar'] = get_avatar_url($current_user->ID);
        $attr['user_name'] = $user_name;
        $attr['invite_url'] = $invite_url;
        $html = $this->cml_load_template( "invite_friends_email_template", "front", $attr );
        return $html;
    }
    
    public function cml_invite_friends() {
        global $cml_lang;
        $html = '';
        $current_user = wp_get_current_user();
        if( $current_user->ID == 0 ) {
            $this->redirect(CML_SITE_BASE_URL);
        }
        
        $invite_gmail_url = $this->cml_get_google_import_url();
        $cml_gcode = $_COOKIE['cml_gcode'];
        
        $inviter_ip = $this->cml_get_client_ip();
        $browser = $this->cml_get_browser_name();
        update_user_meta( $current_user->ID, 'cml_user_browser', $browser['name'] );
        update_user_meta( $current_user->ID, 'cml_user_platform', ucwords($browser['platform']));
        update_user_meta( $current_user->ID, 'cml_user_ip', $inviter_ip );
        update_user_meta( $current_user->ID, 'cml_user_country', $this->cml_ip_info($inviter_ip,'Country'));
        
        $sweepstakes = get_user_meta( $current_user->ID, 'cml_sweepstakes', true );
        $attr = array();
        $invite_url  = CML_SITE_BASE_URL.'?cmluid='.base64_encode($current_user->ID);
        $attr['invite_url'] = $invite_url;
        $attr['email_template'] = CML_SITE_BASE_URL.'?cml_load_email_preview=yes';
        $attr['invite_gmail_url'] = $invite_gmail_url;
        $attr['cml_gcode'] = $cml_gcode;
        $attr['sweepstakes'] = $sweepstakes;
        $attr['send_sms_url'] = CML_SITE_BASE_URL.'?cml_send_sms=yes';
        $attr['invite_url_share_text'] = str_replace('[user-name]', $current_user->display_name, $cml_lang['fb_share_desc']);
        $html = $this->cml_load_template( "invite_friends", "front", $attr );
        return $html;
    }
    
    public function cml_send_sms() {
        
        global $cml_lang;
        $message = '';
        $error = false;
        $current_user = wp_get_current_user();
        if( $current_user->ID == 0 ) {
            $error = true;
            $message = $cml_lang['err_not_authorized'];
        }
        if(!$error) {
            $number = trim($_REQUEST['number']);
            if(strpos($number, "+")===FALSE) {
                $number = "+".$number;
            }
            if($lastid = $this->cml_log_invitations($number)) {
                $invite_url  = CML_SITE_BASE_URL.'?cmluid='.base64_encode($current_user->ID)."&cmlid=".base64_encode($lastid);
                $body = str_replace('[user-name]', $current_user->display_name, $cml_lang['fb_share_desc'])." ".$invite_url;
                $response = $this->cml_send_twilio_message($number,$body);
                $message = $cml_lang['msg_emails_sent_success'];
            }else{
                $error = true;
                $message = $cml_lang['msg_already_invited'].': '.$number;
            }
        }
        
        $return = array( 'error' => $error, 'message'=> $message );            
        header('Content-Type: application/json');
        echo json_encode($return);
        exit();
    }
        
    public function cml_log_invitations( $invited = '' ) {
        
        $current_user = wp_get_current_user();
        
        if( $current_user->ID == 0 ) {
            return false;
        }
        
        if(empty($invited)) {
            return false;
        }
        
        $already_rewarded = $this->cml_get_data("cml_invitations","invited = '".$invited."' AND invited_browser != ''", true);
        if($already_rewarded) {
            return false;
        }
        
        $record = $this->cml_get_data("cml_invitations", "inviter = '".$current_user->ID."' AND invited = '".$invited."'", true);
        if($record) {
            return $record->id;
        }
        $inviter_ip = $this->cml_get_client_ip();
        $browser = $this->cml_get_browser_name();
        $data = array();
        $data['inviter'] = $current_user->ID;
        $data['inviter_browser'] = $browser['name'];
        $data['inviter_platform'] = ucwords($browser['platform']);
        $data['inviter_ip'] = $inviter_ip;
        $data['inviter_country'] = $this->cml_ip_info($inviter_ip,'Country');
        $data['invited'] = $invited;
        $data['date_time'] = strtotime('now');
        $data['date_time_created'] = strtotime('now');
        $data['status'] = 'Sent';
        $lastid = $this->cml_add_record("cml_invitations", $data);
        
        return $lastid;                
    }
    
    public function cml_get_send_sms_html() {
        
        $html = '';   
        
        $attr = array();   
        $attr['ajaxurl'] = admin_url( 'admin-ajax.php' );
        $html = $this->cml_load_template( "cml_send_sms", "front", $attr );
        
        return $html;
    }
    
    public function cml_get_contacts_data() {
        
        $html = '';   
        if(!empty($_REQUEST['error'])) {
            $this->redirect(CML_INVITE_FRIEND_URL);
        }
        require_once CML_PLUGIN_PATH.'google_services/vendor/autoload.php';
        if(isset($_REQUEST['code'])) {            
            $auth_code = $_REQUEST['code'];
            setcookie('cml_gcode', $auth_code, (time()+3600)*6);
            if($_REQUEST['closetab']=='yes') {
                //$this->redirect(CML_INVITE_FRIEND_URL.'?cmlg=1');
            }            
            $max_results = 20000;
            $fields=array(
                'code'=>  urlencode($auth_code),
                'client_id'=>  urlencode(CML_GOOGLE_CLIENT_ID),
                'client_secret'=>  urlencode(CML_GOOGLE_CLIENT_SECRET),
                'redirect_uri'=>  urlencode(CML_SITE_BASE_URL.'?cml_get_gmail_contacts=yes'),
                'grant_type'=>  urlencode('authorization_code')
            );
            $post = '';
            foreach($fields as $key=>$value)
            {
                $post .= $key.'='.$value.'&';
            }
            $post = rtrim($post,'&');
            $result = $this->cml_make_google_curl('https://accounts.google.com/o/oauth2/token',$post);
            
            $response =  json_decode($result);
            $accesstoken = $response->access_token;
            $url = 'https://www.google.com/m8/feeds/contacts/default/full?max-results='.$max_results.'&alt=json&v=3.0&oauth_token='.$accesstoken;
            //$url = 'https://www.googleapis.com/auth/contacts.readonly?max-results='.$max_results.'&alt=json&v=3.0&oauth_token='.$accesstoken;
            $xmlresponse = $this->cml_make_google_curl($url);
            $contacts = json_decode($xmlresponse,true);

            $return = array();
            if (!empty($contacts['feed']['entry'])) {
                foreach($contacts['feed']['entry'] as $contact) {
                    //retrieve Name and email address  
                    if(!empty($contact['gd$email'][0]['address']) && !empty($contact['title']['$t'])) {
                        $return[] = array (
                            'name'=> $contact['title']['$t'],
                            'email' => $contact['gd$email'][0]['address'],
                        );
                    }
                }				
            }
            $attr = array();
            $attr['google_contacts'] = $return;
            $attr['ajaxurl'] = admin_url( 'admin-ajax.php' );
            $html = $this->cml_load_template( "google_contacts_data", "front", $attr );
        }
        return $html;
    }
    
    public function cml_make_google_curl( $url, $post = "" ) {
        
        $curl = curl_init();
        //$userAgent = $_SERVER['HTTP_USER_AGENT'];//'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)';
        curl_setopt($curl, CURLOPT_URL, $url);
        //The URL to fetch. This can also be set when initializing a session with curl_init().
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        //TRUE to return the transfer as a string of the return value of curl_exec() instead of outputting it out directly.
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
        //The number of seconds to wait while trying to connect.
        if ($post != "") {
            curl_setopt($curl, CURLOPT_POST, 5);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
        }
        //curl_setopt($curl, CURLOPT_USERAGENT, $userAgent);
        //The contents of the "User-Agent: " header to be used in a HTTP request.
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, TRUE);
        //To follow any "Location: " header that the server sends as part of the HTTP header.
        curl_setopt($curl, CURLOPT_AUTOREFERER, TRUE);
        //To automatically set the Referer: field in requests where it follows a Location: redirect.
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        //The maximum number of seconds to allow cURL functions to execute.
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        //To stop cURL from verifying the peer's certificate.
        $contents = curl_exec($curl);
        curl_close($curl);
        return $contents;
    }
    
    public function cml_get_google_import_url() {
        
        require_once CML_PLUGIN_PATH.'google_services/vendor/autoload.php';
        
        //setup new google client
        $client = new Google_Client();
        $client -> setApplicationName('CallMeLoco');
        $client -> setClientid(CML_GOOGLE_CLIENT_ID);
        $client -> setClientSecret(CML_GOOGLE_CLIENT_SECRET);        
        $client -> setAccessType('offline');        
        $client -> setScopes('https://www.google.com/m8/feeds');
        //$client -> setScopes('https://www.googleapis.com/auth/contacts.readonly');
        
        $cml_gcode = $_COOKIE['cml_gcode'];
        if(empty($cml_gcode)) {
            $client->setApprovalPrompt('force');
            $client -> setRedirectUri(CML_SITE_BASE_URL.'?cml_get_gmail_contacts=yes');
        }else{
            $client -> setRedirectUri(CML_SITE_BASE_URL.'?cml_get_gmail_contacts=yes');
        }
        
        $googleImportUrl = $client -> createAuthUrl();
        
        return $googleImportUrl;
    }
    
    public function cml_send_invite_friend_mail() {
        global $cml_lang;
        $error = false;
        $message = '';
        $current_user = wp_get_current_user();
        if( $current_user->ID == 0 ) {
            $error = true;
            $message = $cml_lang['err_not_authorized'];
        }
        $emails = $_REQUEST['emails'];
        
        if(empty($emails)) {
            $error = true;
            $message = $cml_lang['err_not_authorized'];
        }
        
        if(!$error) {
            $emails_arr = explode(",", $emails);
            foreach( $emails_arr as $email ) {
                if($lastid = $this->cml_log_invitations($email)) {
                    $invite_url  = CML_SITE_BASE_URL.'?cmluid='.base64_encode($current_user->ID)."&cmlid=".base64_encode($lastid);
                    $body = $this->cml_get_invite_friends_email_template();
                    $subject = $cml_lang['invite_friends_mail_subject'];
                    $to = $email;
                    $headers = array();
                    $headers[] = 'Content-Type: text/html; charset=UTF-8';
                    $headers[] = 'From: '.CML_SITE_NAME.' <registration@callmeloco.com>';
                    if(wp_mail( $to, $subject, $body, $headers )) {
                        $message = $cml_lang['msg_emails_sent_success'];
                    }else{
                        $message = $cml_lang['err_emails_sent'];
                    }
                }else{
                    $message = $message.$cml_lang['msg_already_invited'].': '.$email.'\n';
                }
            }
        }
        
        $return = array( 'error' => $error, 'message'=> $message );
            
        header('Content-Type: application/json');
        echo json_encode($return);
        exit();
    }
    
}

$cml_front = new CML_Front();